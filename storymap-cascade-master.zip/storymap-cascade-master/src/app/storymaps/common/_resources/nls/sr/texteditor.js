/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Nastavite svoju priču ovde..."
    },
    "blockAdd": {
      "text": "Tekst",
      "media": "Mediji",
      "title": "Naslov",
      "immersive": "Sveobuhvatno"
    },
    "link": {
      "invite": "Nalepite ili otkucajte link..."
    },
    "color": {
      "choose": "odaberite",
      "cancel": "otkaži",
      "clear": "Obriši boju"
    }
  }
});