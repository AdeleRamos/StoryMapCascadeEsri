/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Jatka tarinaasi tässä..."
    },
    "blockAdd": {
      "text": "Teksti",
      "media": "Media",
      "title": "Otsikko",
      "immersive": "Immersiivinen"
    },
    "link": {
      "invite": "Liitä tai kirjoita linkki..."
    },
    "color": {
      "choose": "valitse",
      "cancel": "peruuta",
      "clear": "Tyhjennä väri"
    }
  }
});