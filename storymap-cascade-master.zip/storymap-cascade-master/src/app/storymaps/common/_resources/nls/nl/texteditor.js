/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Ga hier verder met uw verhaal..."
    },
    "blockAdd": {
      "text": "Tekst",
      "media": "Media",
      "title": "Titel",
      "immersive": "Meeslepend"
    },
    "link": {
      "invite": "Plak of typ een koppeling..."
    },
    "color": {
      "choose": "kies",
      "cancel": "annuleren",
      "clear": "Kleur wissen"
    }
  }
});