/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Poursuivez votre récit ici..."
    },
    "blockAdd": {
      "text": "Texte",
      "media": "Elément multimédia",
      "title": "Titre",
      "immersive": "Immersif"
    },
    "link": {
      "invite": "Collez ou saisissez un lien..."
    },
    "color": {
      "choose": "choisir",
      "cancel": "annuler",
      "clear": "Effacer la couleur"
    }
  }
});