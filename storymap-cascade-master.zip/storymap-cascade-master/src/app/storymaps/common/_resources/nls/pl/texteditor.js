/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Kontynuuj narrację tutaj..."
    },
    "blockAdd": {
      "text": "Tekst",
      "media": "Multimedia",
      "title": "Tytuł",
      "immersive": "Imersyjne"
    },
    "link": {
      "invite": "Wklej lub wpisz łącze..."
    },
    "color": {
      "choose": "wybierz",
      "cancel": "anuluj",
      "clear": "Wyczyść kolor"
    }
  }
});