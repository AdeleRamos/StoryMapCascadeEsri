/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Continuaţi-vă relatarea aici..."
    },
    "blockAdd": {
      "text": "Text",
      "media": "Media",
      "title": "Titlu",
      "immersive": "Captivantă"
    },
    "link": {
      "invite": "Lipiţi sau tastaţi un link..."
    },
    "color": {
      "choose": "alegere",
      "cancel": "anulare",
      "clear": "Golire culoare"
    }
  }
});