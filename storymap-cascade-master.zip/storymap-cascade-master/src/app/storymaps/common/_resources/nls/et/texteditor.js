/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Jätkake oma lugu siit."
    },
    "blockAdd": {
      "text": "Tekst",
      "media": "Meedia",
      "title": "Pealkiri",
      "immersive": "Detailne"
    },
    "link": {
      "invite": "Kleepige või tippige link."
    },
    "color": {
      "choose": "Vali",
      "cancel": "tühista",
      "clear": "Eemalda värv"
    }
  }
});