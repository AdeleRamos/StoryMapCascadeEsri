/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Lanjutkan cerita Anda di sini..."
    },
    "blockAdd": {
      "text": "Teks",
      "media": "Media",
      "title": "Judul",
      "immersive": "Imersif"
    },
    "link": {
      "invite": "Tempel atau ketik tautan..."
    },
    "color": {
      "choose": "pilih",
      "cancel": "batal",
      "clear": "Hapus warna"
    }
  }
});