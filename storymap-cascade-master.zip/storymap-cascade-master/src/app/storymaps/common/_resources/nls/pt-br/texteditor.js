/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Continue sua história aqui..."
    },
    "blockAdd": {
      "text": "Texto",
      "media": "Mídia",
      "title": "Título",
      "immersive": "Profundo"
    },
    "link": {
      "invite": "Cole ou digite um link..."
    },
    "color": {
      "choose": "escolha",
      "cancel": "cancelar",
      "clear": "Limpar cor"
    }
  }
});