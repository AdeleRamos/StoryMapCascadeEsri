/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Setzen Sie Ihre Story hier fort..."
    },
    "blockAdd": {
      "text": "Text",
      "media": "Medien",
      "title": "Titel",
      "immersive": "Immersiv"
    },
    "link": {
      "invite": "Fügen oder geben Sie einen Link ein..."
    },
    "color": {
      "choose": "Auswählen",
      "cancel": "Abbrechen",
      "clear": "Farbe löschen"
    }
  }
});