/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Turpiniet šeit savu stāstu..."
    },
    "blockAdd": {
      "text": "Teksts",
      "media": "Mediji",
      "title": "Virsraksts",
      "immersive": "Iekļaujošs"
    },
    "link": {
      "invite": "Ielīmējiet vai ierakstiet saiti..."
    },
    "color": {
      "choose": "izvēlēties",
      "cancel": "atcelt",
      "clear": "Notīrīt krāsu"
    }
  }
});