/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Tęskite savo pasakojimą čia..."
    },
    "blockAdd": {
      "text": "Tekstas",
      "media": "Medija",
      "title": "Pavadinimas",
      "immersive": "Fiksuotas"
    },
    "link": {
      "invite": "Įklijuokite arba įrašykite nuorodą..."
    },
    "color": {
      "choose": "pasirinkti",
      "cancel": "atšaukti",
      "clear": "Išvalyti spalvą"
    }
  }
});