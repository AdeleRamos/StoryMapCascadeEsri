/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Hikayenize burada devam edin..."
    },
    "blockAdd": {
      "text": "Metin",
      "media": "Ortam",
      "title": "Başlık",
      "immersive": "Ayrıntılar"
    },
    "link": {
      "invite": "Bir bağlantı yapıştırın veya yazın..."
    },
    "color": {
      "choose": "seçin",
      "cancel": "iptal",
      "clear": "Rengi temizle"
    }
  }
});