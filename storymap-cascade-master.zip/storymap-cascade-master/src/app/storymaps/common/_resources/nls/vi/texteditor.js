/* eslint quotes: ["error", "double"] */
define({
  "textEditor": {
    "placeholder": {
      "continueStory": "Tiếp tục câu chuyện của bạn ở đây..."
    },
    "blockAdd": {
      "text": "Văn bản",
      "media": "Phương tiện truyền thông",
      "title": "Tiêu đề",
      "immersive": "Phong phú"
    },
    "link": {
      "invite": "Dán hoặc gõ đường liên kết..."
    },
    "color": {
      "choose": "chọn",
      "cancel": "hủy",
      "clear": "Xóa màu"
    }
  }
});