define([
  './CoverCommonEffects'
], function(
  //CoverCommonEffects
) {
  return function ScaleCover() {
    this.dataViews = 1;
    this.layoutType = 'static';

    this.displayCover = function() {
      //
    };

    this.onScroll = function() {
      //
    };
  };
});
