let appState = {
  privileges: null,
  orgId: '',
  premiumManager: null
};

export default appState;
